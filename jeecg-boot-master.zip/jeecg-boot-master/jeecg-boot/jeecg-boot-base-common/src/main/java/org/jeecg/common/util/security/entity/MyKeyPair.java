package org.jeecg.common.util.security.entity;

import lombok.Data;

@Data
public class MyKeyPair {
    private String priKey;
    private String pubKey;
}
