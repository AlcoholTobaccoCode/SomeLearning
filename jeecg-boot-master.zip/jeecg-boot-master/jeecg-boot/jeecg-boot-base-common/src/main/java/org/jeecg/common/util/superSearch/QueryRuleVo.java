package org.jeecg.common.util.superSearch;

import lombok.Data;

@Data
public class QueryRuleVo {

	private String field;
	private String rule;
	private String val;
}	
